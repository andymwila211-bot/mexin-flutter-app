package com.softclicks.mexintext.manager

import javax.inject.Inject

class ReferralManagerImpl @Inject constructor() : ReferralManager {

    override suspend fun trackReferrer() {
    }

}