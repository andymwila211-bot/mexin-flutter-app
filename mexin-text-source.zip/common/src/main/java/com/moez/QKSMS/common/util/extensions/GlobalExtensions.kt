package com.softclicks.mexintext.common.util.extensions

fun now(): Long {
    return System.currentTimeMillis()
}
