package com.softclicks.mexintext.feature.messageutils

import com.softclicks.mexintext.repository.MessageRepository

data class MessageUtilsState(
    val autoDeduplicateMessages: Boolean = false,
    val deduplicationProgress: MessageRepository.DeduplicationProgress = MessageRepository.DeduplicationProgress.Idle,

    val autoDelete: Int = 0,
)
