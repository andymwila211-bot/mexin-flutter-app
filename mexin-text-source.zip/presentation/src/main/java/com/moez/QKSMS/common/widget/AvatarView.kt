/*
 * Copyright (C) 2017 Moez Bhatti <moez.bhatti@gmail.com>
 *
 * This file is part of QKSMS.
 *
 * QKSMS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * QKSMS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with QKSMS.  If not, see <http://www.gnu.org/licenses/>.
 */
package com.softclicks.mexintext.common.widget

import android.content.Context
import android.graphics.Outline
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import com.softclicks.mexintext.R
import com.softclicks.mexintext.common.Navigator
import com.softclicks.mexintext.common.util.Colors
import com.softclicks.mexintext.common.util.extensions.setBackgroundTint
import com.softclicks.mexintext.common.util.extensions.setTint
import com.softclicks.mexintext.databinding.AvatarViewBinding
import com.softclicks.mexintext.injection.appComponent
import com.softclicks.mexintext.model.Recipient
import com.softclicks.mexintext.util.GlideApp
import javax.inject.Inject

class AvatarView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    @Inject lateinit var colors: Colors
    @Inject lateinit var navigator: Navigator

    private var lookupKey: String? = null
    private var fullName: String? = null
    private var photoUri: String? = null
    private var lastUpdated: Long? = null
    private var theme: Colors.Theme
    private var layout: AvatarViewBinding

    init {
        if (!isInEditMode) {
            appComponent.inject(this)
        }

        theme = colors.theme()

        layout = AvatarViewBinding.inflate(LayoutInflater.from(context), this)
        setBackgroundResource(R.drawable.avatar_fill)
        outlineProvider = ShieldOutlineProvider
        clipToOutline = true
    }

    /**
     * Brand avatar silhouette: a "chamfered shield" — two opposite corners cut
     * at an angle, two corners rounded. Echoes the app mark's contrast between
     * angular wings and round dots, instead of a plain circle or squircle.
     * Path is fully convex (required for Outline.setConvexPath).
     */
    private object ShieldOutlineProvider : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            val w = view.width.toFloat()
            val h = view.height.toFloat()
            if (w <= 0f || h <= 0f) return

            val size = minOf(w, h)
            val chamfer = size * 0.30f   // top-left / bottom-right: angled cut
            val round = size * 0.16f     // top-right / bottom-left: rounded

            val path = Path().apply {
                moveTo(chamfer, 0f)
                lineTo(w - round, 0f)
                arcTo(RectF(w - 2 * round, 0f, w, 2 * round), -90f, 90f)
                lineTo(w, h - chamfer)
                lineTo(w - chamfer, h)
                lineTo(round, h)
                arcTo(RectF(0f, h - 2 * round, 2 * round, h), 90f, 90f)
                lineTo(0f, chamfer)
                lineTo(chamfer, 0f)
                close()
            }

            outline.setConvexPath(path)
        }
    }

    /**
     * Use the contact information to display the avatar.
     */
    fun setRecipient(recipient: Recipient?) {
        lookupKey = recipient?.contact?.lookupKey
        fullName = recipient?.contact?.name
        photoUri = recipient?.contact?.photoUri
        lastUpdated = recipient?.contact?.lastUpdate
        theme = colors.theme(recipient)
        updateView()
    }

    override fun onFinishInflate() {
        super.onFinishInflate()

        if (!isInEditMode) {
            updateView()
        }
    }

    private fun updateView() {
        // Apply theme
        setBackgroundTint(theme.theme)
        layout.initial.setTextColor(theme.textPrimary)
        layout.icon.setTint(theme.textPrimary)

        val initials = fullName
                ?.substringBefore(',')
                ?.split(" ").orEmpty()
                .filter { name -> name.isNotEmpty() }
                .map { name -> name[0] }
                .filter { initial -> initial.isLetterOrDigit() }
                .map { initial -> initial.toString() }

        if (initials.isNotEmpty()) {
            layout.initial.text = if (initials.size > 1) initials.first() + initials.last() else initials.first()
            layout.icon.visibility = GONE
        } else {
            layout.initial.text = null
            layout.icon.visibility = VISIBLE
        }

        layout.photo.setImageDrawable(null)
        photoUri?.let { photoUri ->
            GlideApp.with(layout.photo)
                    .load(photoUri)
                    .into(layout.photo)
        }
    }
}
