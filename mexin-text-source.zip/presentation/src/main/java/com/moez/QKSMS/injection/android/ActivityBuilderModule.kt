/*
 * Copyright (C) 2017 Moez Bhatti <moez.bhatti@gmail.com>
 *
 * This file is part of QKSMS.
 *
 * QKSMS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * QKSMS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with QKSMS.  If not, see <http://www.gnu.org/licenses/>.
 */
package com.softclicks.mexintext.injection.android

import dagger.Module
import dagger.android.ContributesAndroidInjector
import com.softclicks.mexintext.feature.backup.BackupActivity
import com.softclicks.mexintext.feature.blocking.BlockingActivity
import com.softclicks.mexintext.feature.compose.ComposeActivity
import com.softclicks.mexintext.feature.compose.ComposeActivityModule
import com.softclicks.mexintext.feature.contacts.ContactsActivity
import com.softclicks.mexintext.feature.contacts.ContactsActivityModule
import com.softclicks.mexintext.feature.conversationinfo.ConversationInfoActivity
import com.softclicks.mexintext.feature.gallery.GalleryActivity
import com.softclicks.mexintext.feature.gallery.GalleryActivityModule
import com.softclicks.mexintext.feature.main.MainActivity
import com.softclicks.mexintext.feature.main.MainActivityModule
import com.softclicks.mexintext.feature.messageutils.MessageUtilsActivity
import com.softclicks.mexintext.feature.notificationprefs.NotificationPrefsActivity
import com.softclicks.mexintext.feature.notificationprefs.NotificationPrefsActivityModule
import com.softclicks.mexintext.feature.plus.PlusActivity
import com.softclicks.mexintext.feature.plus.PlusActivityModule
import com.softclicks.mexintext.feature.qkreply.QkReplyActivity
import com.softclicks.mexintext.feature.qkreply.QkReplyActivityModule
import com.softclicks.mexintext.feature.scheduled.ScheduledActivity
import com.softclicks.mexintext.feature.scheduled.ScheduledActivityModule
import com.softclicks.mexintext.feature.settings.SettingsActivity
import com.softclicks.mexintext.feature.settings.about.AboutActivity
import com.softclicks.mexintext.injection.scope.ActivityScope

@Module
abstract class ActivityBuilderModule {

    @ActivityScope
    @ContributesAndroidInjector(modules = [MainActivityModule::class])
    abstract fun bindMainActivity(): MainActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [PlusActivityModule::class])
    abstract fun bindPlusActivity(): PlusActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindBackupActivity(): BackupActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [ComposeActivityModule::class])
    abstract fun bindComposeActivity(): ComposeActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [ContactsActivityModule::class])
    abstract fun bindContactsActivity(): ContactsActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindConversationInfoActivity(): ConversationInfoActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [GalleryActivityModule::class])
    abstract fun bindGalleryActivity(): GalleryActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [NotificationPrefsActivityModule::class])
    abstract fun bindNotificationPrefsActivity(): NotificationPrefsActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [QkReplyActivityModule::class])
    abstract fun bindQkReplyActivity(): QkReplyActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [ScheduledActivityModule::class])
    abstract fun bindScheduledActivity(): ScheduledActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindMessageUtilsActivity(): MessageUtilsActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindSettingsActivity(): SettingsActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindAboutActivity(): AboutActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindBlockingActivity(): BlockingActivity

}
