/*
 * Copyright (C) 2017 Moez Bhatti <moez.bhatti@gmail.com>
 *
 * This file is part of QKSMS.
 *
 * QKSMS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * QKSMS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with QKSMS.  If not, see <http://www.gnu.org/licenses/>.
 */
package com.softclicks.mexintext.injection

import dagger.Component
import dagger.android.support.AndroidSupportInjectionModule
import com.softclicks.mexintext.common.QKApplication
import com.softclicks.mexintext.common.QkDialog
import com.softclicks.mexintext.common.util.QkChooserTargetService
import com.softclicks.mexintext.common.widget.AvatarView
import com.softclicks.mexintext.common.widget.PagerTitleView
import com.softclicks.mexintext.common.widget.PreferenceView
import com.softclicks.mexintext.common.widget.QkEditText
import com.softclicks.mexintext.common.widget.QkSwitch
import com.softclicks.mexintext.common.widget.QkTextView
import com.softclicks.mexintext.common.widget.RadioPreferenceView
import com.softclicks.mexintext.feature.backup.BackupController
import com.softclicks.mexintext.feature.blocking.BlockingController
import com.softclicks.mexintext.feature.blocking.filters.MessageContentFiltersController
import com.softclicks.mexintext.feature.blocking.manager.BlockingManagerController
import com.softclicks.mexintext.feature.blocking.messages.BlockedMessagesController
import com.softclicks.mexintext.feature.blocking.numbers.BlockedNumbersController
import com.softclicks.mexintext.feature.compose.editing.DetailedChipView
import com.softclicks.mexintext.feature.conversationinfo.injection.ConversationInfoComponent
import com.softclicks.mexintext.feature.messageutils.MessageUtilsController
import com.softclicks.mexintext.feature.settings.SettingsController
import com.softclicks.mexintext.feature.settings.about.AboutController
import com.softclicks.mexintext.feature.settings.swipe.SwipeActionsController
import com.softclicks.mexintext.feature.themepicker.injection.ThemePickerComponent
import com.softclicks.mexintext.feature.widget.WidgetAdapter
import com.softclicks.mexintext.injection.android.ActivityBuilderModule
import com.softclicks.mexintext.injection.android.BroadcastReceiverBuilderModule
import com.softclicks.mexintext.injection.android.ServiceBuilderModule
import javax.inject.Singleton

@Singleton
@Component(modules = [
    AndroidSupportInjectionModule::class,
    AppModule::class,
    ActivityBuilderModule::class,
    BroadcastReceiverBuilderModule::class,
    ServiceBuilderModule::class])
interface AppComponent {

    fun conversationInfoBuilder(): ConversationInfoComponent.Builder
    fun themePickerBuilder(): ThemePickerComponent.Builder

    fun inject(application: QKApplication)

    fun inject(controller: AboutController)
    fun inject(controller: BackupController)
    fun inject(controller: BlockedMessagesController)
    fun inject(controller: BlockedNumbersController)
    fun inject(controller: MessageContentFiltersController)
    fun inject(controller: BlockingController)
    fun inject(controller: BlockingManagerController)
    fun inject(controller: MessageUtilsController)
    fun inject(controller: SettingsController)
    fun inject(controller: SwipeActionsController)

    fun inject(dialog: QkDialog)

    fun inject(service: WidgetAdapter)

    /**
     * This can't use AndroidInjection, or else it will crash on pre-marshmallow devices
     */
    fun inject(service: QkChooserTargetService)

    fun inject(view: AvatarView)
    fun inject(view: DetailedChipView)
    fun inject(view: PagerTitleView)
    fun inject(view: PreferenceView)
    fun inject(view: RadioPreferenceView)
    fun inject(view: QkEditText)
    fun inject(view: QkSwitch)
    fun inject(view: QkTextView)

}
