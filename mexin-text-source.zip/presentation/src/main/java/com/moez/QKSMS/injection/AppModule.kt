/*
 * Copyright (C) 2017 Moez Bhatti <moez.bhatti@gmail.com>
 *
 * This file is part of QKSMS.
 *
 * QKSMS is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * QKSMS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with QKSMS.  If not, see <http://www.gnu.org/licenses/>.
 */
package com.softclicks.mexintext.injection

import android.app.Application
import android.content.ContentResolver
import android.content.Context
import android.content.SharedPreferences
import android.preference.PreferenceManager
import androidx.lifecycle.ViewModelProvider
import androidx.work.WorkerFactory
import com.f2prateek.rx.preferences2.RxSharedPreferences
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import dagger.Module
import dagger.Provides
import com.softclicks.mexintext.blocking.BlockingClient
import com.softclicks.mexintext.blocking.BlockingManager
import com.softclicks.mexintext.common.ViewModelFactory
import com.softclicks.mexintext.common.util.BillingManagerImpl
import com.softclicks.mexintext.common.util.NotificationManagerImpl
import com.softclicks.mexintext.common.util.ShortcutManagerImpl
import com.softclicks.mexintext.feature.conversationinfo.injection.ConversationInfoComponent
import com.softclicks.mexintext.feature.themepicker.injection.ThemePickerComponent
import com.softclicks.mexintext.listener.ContactAddedListener
import com.softclicks.mexintext.listener.ContactAddedListenerImpl
import com.softclicks.mexintext.manager.ActiveConversationManager
import com.softclicks.mexintext.manager.ActiveConversationManagerImpl
import com.softclicks.mexintext.manager.AlarmManager
import com.softclicks.mexintext.manager.AlarmManagerImpl
import com.softclicks.mexintext.manager.BillingManager
import com.softclicks.mexintext.manager.ChangelogManager
import com.softclicks.mexintext.manager.ChangelogManagerImpl
import com.softclicks.mexintext.manager.KeyManager
import com.softclicks.mexintext.manager.KeyManagerImpl
import com.softclicks.mexintext.manager.NotificationManager
import com.softclicks.mexintext.manager.PermissionManager
import com.softclicks.mexintext.manager.PermissionManagerImpl
import com.softclicks.mexintext.manager.RatingManager
import com.softclicks.mexintext.manager.ReferralManager
import com.softclicks.mexintext.manager.ReferralManagerImpl
import com.softclicks.mexintext.manager.ShortcutManager
import com.softclicks.mexintext.manager.WidgetManager
import com.softclicks.mexintext.manager.WidgetManagerImpl
import com.softclicks.mexintext.mapper.CursorToContact
import com.softclicks.mexintext.mapper.CursorToContactGroup
import com.softclicks.mexintext.mapper.CursorToContactGroupImpl
import com.softclicks.mexintext.mapper.CursorToContactGroupMember
import com.softclicks.mexintext.mapper.CursorToContactGroupMemberImpl
import com.softclicks.mexintext.mapper.CursorToContactImpl
import com.softclicks.mexintext.mapper.CursorToConversation
import com.softclicks.mexintext.mapper.CursorToConversationImpl
import com.softclicks.mexintext.mapper.CursorToMessage
import com.softclicks.mexintext.mapper.CursorToMessageImpl
import com.softclicks.mexintext.mapper.CursorToPart
import com.softclicks.mexintext.mapper.CursorToPartImpl
import com.softclicks.mexintext.mapper.CursorToRecipient
import com.softclicks.mexintext.mapper.CursorToRecipientImpl
import com.softclicks.mexintext.mapper.RatingManagerImpl
import com.softclicks.mexintext.repository.BackupRepository
import com.softclicks.mexintext.repository.BackupRepositoryImpl
import com.softclicks.mexintext.repository.BlockingRepository
import com.softclicks.mexintext.repository.BlockingRepositoryImpl
import com.softclicks.mexintext.repository.ContactRepository
import com.softclicks.mexintext.repository.ContactRepositoryImpl
import com.softclicks.mexintext.repository.ConversationRepository
import com.softclicks.mexintext.repository.ConversationRepositoryImpl
import com.softclicks.mexintext.repository.EmojiReactionRepository
import com.softclicks.mexintext.repository.EmojiReactionRepositoryImpl
import com.softclicks.mexintext.repository.MessageContentFilterRepository
import com.softclicks.mexintext.repository.MessageContentFilterRepositoryImpl
import com.softclicks.mexintext.repository.MessageRepository
import com.softclicks.mexintext.repository.MessageRepositoryImpl
import com.softclicks.mexintext.repository.ScheduledMessageRepository
import com.softclicks.mexintext.repository.ScheduledMessageRepositoryImpl
import com.softclicks.mexintext.repository.SyncRepository
import com.softclicks.mexintext.repository.SyncRepositoryImpl
import com.softclicks.mexintext.worker.InjectionWorkerFactory
import javax.inject.Singleton

@Module(subcomponents = [
    ConversationInfoComponent::class,
    ThemePickerComponent::class])
class AppModule(private var application: Application) {

    @Provides
    @Singleton
    fun provideContext(): Context = application

    @Provides
    fun provideContentResolver(context: Context): ContentResolver = context.contentResolver

    @Provides
    @Singleton
    fun provideSharedPreferences(context: Context): SharedPreferences {
        return PreferenceManager.getDefaultSharedPreferences(context)
    }

    @Provides
    @Singleton
    fun provideRxPreferences(preferences: SharedPreferences): RxSharedPreferences {
        return RxSharedPreferences.create(preferences)
    }

    @Provides
    @Singleton
    fun provideMoshi(): Moshi {
        return Moshi.Builder()
                .add(KotlinJsonAdapterFactory())
                .build()
    }

    @Provides
    fun provideViewModelFactory(factory: ViewModelFactory): ViewModelProvider.Factory = factory

    // Listener

    @Provides
    fun provideContactAddedListener(listener: ContactAddedListenerImpl): ContactAddedListener = listener

    // Manager

    @Provides
    fun provideBillingManager(manager: BillingManagerImpl): BillingManager = manager

    @Provides
    fun provideActiveConversationManager(manager: ActiveConversationManagerImpl): ActiveConversationManager = manager

    @Provides
    fun provideAlarmManager(manager: AlarmManagerImpl): AlarmManager = manager

    @Provides
    fun blockingClient(manager: BlockingManager): BlockingClient = manager

    @Provides
    fun changelogManager(manager: ChangelogManagerImpl): ChangelogManager = manager

    @Provides
    fun provideKeyManager(manager: KeyManagerImpl): KeyManager = manager

    @Provides
    fun provideNotificationsManager(manager: NotificationManagerImpl): NotificationManager = manager

    @Provides
    fun providePermissionsManager(manager: PermissionManagerImpl): PermissionManager = manager

    @Provides
    fun provideRatingManager(manager: RatingManagerImpl): RatingManager = manager

    @Provides
    fun provideShortcutManager(manager: ShortcutManagerImpl): ShortcutManager = manager

    @Provides
    fun provideReferralManager(manager: ReferralManagerImpl): ReferralManager = manager

    @Provides
    fun provideWidgetManager(manager: WidgetManagerImpl): WidgetManager = manager

    // Mapper

    @Provides
    fun provideCursorToContact(mapper: CursorToContactImpl): CursorToContact = mapper

    @Provides
    fun provideCursorToContactGroup(mapper: CursorToContactGroupImpl): CursorToContactGroup = mapper

    @Provides
    fun provideCursorToContactGroupMember(mapper: CursorToContactGroupMemberImpl): CursorToContactGroupMember = mapper

    @Provides
    fun provideCursorToConversation(mapper: CursorToConversationImpl): CursorToConversation = mapper

    @Provides
    fun provideCursorToMessage(mapper: CursorToMessageImpl): CursorToMessage = mapper

    @Provides
    fun provideCursorToPart(mapper: CursorToPartImpl): CursorToPart = mapper

    @Provides
    fun provideCursorToRecipient(mapper: CursorToRecipientImpl): CursorToRecipient = mapper

    // Repository

    @Provides
    fun provideBackupRepository(repository: BackupRepositoryImpl): BackupRepository = repository

    @Provides
    fun provideBlockingRepository(repository: BlockingRepositoryImpl): BlockingRepository = repository

    @Provides
    fun provideMessageContentFilterRepository(repository: MessageContentFilterRepositoryImpl): MessageContentFilterRepository = repository

    @Provides
    fun provideContactRepository(repository: ContactRepositoryImpl): ContactRepository = repository

    @Provides
    fun provideConversationRepository(repository: ConversationRepositoryImpl): ConversationRepository = repository

    @Provides
    fun provideMessageRepository(repository: MessageRepositoryImpl): MessageRepository = repository

    @Provides
    fun provideScheduledMessagesRepository(repository: ScheduledMessageRepositoryImpl): ScheduledMessageRepository = repository

    @Provides
    fun provideSyncRepository(repository: SyncRepositoryImpl): SyncRepository = repository

    @Provides
    fun provideEmojiReactionRepository(repository: EmojiReactionRepositoryImpl): EmojiReactionRepository = repository

    // worker factory
    @Provides
    fun provideWorkerFactory(workerFactory: InjectionWorkerFactory): WorkerFactory = workerFactory
}