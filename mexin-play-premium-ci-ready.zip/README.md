# Mexin Play (Phase 3: navigable app)

SOFTCLICKS TECH. Multi-purpose media player for Android — music (**Pulse**)
and video (**Flux**) in one app, themed distinctly but sharing one
playback engine and one shuffle brain.

## What's in this drop

- **`:app`** — first real installable module. `MexinPlayApplication` owns
  the single `PlaybackController` + history database instance; `MainActivity`
  hosts `MexinNavHost`, which switches between Pulse and Flux via a
  `GlassSurface`-based bottom bar (so the nav chrome itself proves out the
  glass component under real interaction, not just a static screen).
- Phase 1 (`:core-player`) and Phase 2 (`:core-ui-glass`,
  `:feature-pulse`, `:feature-flux`) unchanged — see git history for
  those notes.

## Known gap in this drop

`PulseHomeScreen`/`FluxHomeScreen` are still called with
`nowPlaying = null` — there's no real media source wired up yet (no
device library scan, no file picker). The nav shell and glass bar are
real and interactive; the content behind them is still a stub. That's
the next isolated step, not bundled here on purpose — media loading
touches permissions (`READ_MEDIA_AUDIO`/`READ_MEDIA_VIDEO` on API 33+)
and deserves its own verified pass rather than riding along with the
nav/app-shell change.

No launcher icon or app theme resources yet either — omitted
deliberately to avoid missing-resource compile failures; app currently
uses the system default icon/theme. Visual polish is separate from
"does it compile and run."

## Why Haze still isn't in

Same reason as Phase 2: version-compatibility risk between the current
Haze release and plain AndroidX Compose couldn't be verified without a
live compile. `GlassSurface` is still the seam — the bottom bar and any
future glass panels only need Haze added on the inside of that one file
once it's confirmed compatible.

## Kotlin/AGP/Compose versions (unchanged from Phase 2)

Kotlin `2.0.21`, KSP `2.0.21-1.0.28`, AGP `8.6.0`,
`org.jetbrains.kotlin.plugin.compose`, Compose BOM `2024.10.01`.
`:app` additionally adds `androidx.activity:activity-compose:1.9.3`,
`androidx.navigation:navigation-compose:2.8.3`, `androidx.core:core-ktx:1.13.1`.

## Deliberately not decided/built here

- Engine choice: staying on ExoPlayer, not libVLC.
- UI: themed variants (different palette per Pulse/Flux, same shell),
  not two fully separate interaction paradigms.
- Real Haze blur.
- Media loading / library scanning — next step.
- Smart shuffle isn't wired into any screen yet — `SmartShuffleEngine`
  exists and is unit-tested in isolation, but nothing calls it from the
  app yet since there's no real media list to shuffle.

## CI

`.github/workflows/build.yml` — maintained directly in the GitHub web
editor. **Needs another manual update** to build `:app` and produce a
real `.apk` (not just `.aar`s) — updated content provided separately.

No committed `gradle-wrapper.jar` — workflow calls `gradle` directly,
not `./gradlew`.
