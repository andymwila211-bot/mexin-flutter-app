# MEXIN PLAY — mobile ZIP build

This project is packaged for the phone-only workflow: upload this ZIP to a GitHub repository, then let GitHub Actions extract and build it.

The workflow is included at `.github/workflows/build.yml`.

## Mobile workflow

1. Create or open a GitHub repository.
2. Upload this ZIP file to the repository.
3. Keep `.github/workflows/build.yml` in the repository. If GitHub treats the uploaded ZIP as a single file, extract it first in the GitHub web editor or upload the ZIP alongside the workflow file.
4. Push to `main`/`master`, or run the workflow manually from Actions.
5. Download `mexin-play-app-debug-apk` from the completed workflow.

## Build environment

- Ubuntu GitHub runner
- JDK 17
- Gradle 8.7 installed by `gradle/actions/setup-gradle@v4`
- Android Gradle Plugin 8.6.0
- Kotlin 2.0.21
- compileSdk 34

The workflow deliberately installs Gradle instead of requiring a Gradle wrapper inside the ZIP, which makes the phone-upload workflow reliable even when the ZIP was created without `gradlew`.
