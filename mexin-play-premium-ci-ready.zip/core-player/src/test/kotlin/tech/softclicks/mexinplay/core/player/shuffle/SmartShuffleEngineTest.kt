package tech.softclicks.mexinplay.core.player.shuffle

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import tech.softclicks.mexinplay.core.player.history.MediaPlayStats
import tech.softclicks.mexinplay.core.player.model.MediaType
import tech.softclicks.mexinplay.core.player.model.PlayableItem
import kotlin.random.Random

class SmartShuffleEngineTest {

    private fun item(id: String) = PlayableItem(
        id = id,
        uri = "content://$id",
        title = id,
        artistOrChannel = null,
        durationMs = 180_000,
        type = MediaType.PULSE,
    )

    @Test
    fun `returns every candidate exactly once`() {
        val engine = SmartShuffleEngine(random = Random(seed = 42))
        val candidates = listOf(item("a"), item("b"), item("c"), item("d"))

        val result = engine.weightedShuffle(
            candidates = candidates,
            statsByMediaId = emptyMap(),
            currentEpochMs = 1_000_000L,
            currentHourOfDay = 20,
        )

        assertEquals(candidates.toSet(), result.toSet())
        assertEquals(candidates.size, result.size)
    }

    @Test
    fun `heavily skipped item is scored lower than a clean one`() {
        val engine = SmartShuffleEngine()
        val now = 10_000_000L

        val skippedStats = MediaPlayStats(mediaId = "skipped", playCount = 10, skipCount = 9, lastPlayedAt = now - 3_600_000)
        val cleanStats = MediaPlayStats(mediaId = "clean", playCount = 10, skipCount = 0, lastPlayedAt = now - 3_600_000)

        // Run many trials since selection is weighted-random, not fixed order.
        var cleanPickedFirstCount = 0
        val trials = 200
        repeat(trials) {
            val result = engine.weightedShuffle(
                candidates = listOf(item("skipped"), item("clean")),
                statsByMediaId = mapOf("skipped" to skippedStats, "clean" to cleanStats),
                currentEpochMs = now,
                currentHourOfDay = 12,
            )
            if (result.first().id == "clean") cleanPickedFirstCount++
        }

        // Not a hard guarantee (it's weighted, not deterministic) but the
        // clean item should win a clear majority of the time.
        assertTrue(cleanPickedFirstCount > trials * 0.65)
    }

    @Test
    fun `unplayed items are not excluded from results`() {
        val engine = SmartShuffleEngine(random = Random(seed = 7))
        val candidates = listOf(item("new"), item("known"))
        val stats = mapOf(
            "known" to MediaPlayStats(mediaId = "known", playCount = 5, skipCount = 0, lastPlayedAt = 5_000L)
        )

        val result = engine.weightedShuffle(
            candidates = candidates,
            statsByMediaId = stats,
            currentEpochMs = 100_000L,
            currentHourOfDay = 9,
        )

        assertTrue(result.any { it.id == "new" })
    }
}
