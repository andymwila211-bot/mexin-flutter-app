package tech.softclicks.mexinplay.core.player.playlist

import androidx.room.ColumnInfo
import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

/**
 * Playlists are user-created, manual — separate from SmartShuffleEngine's
 * auto-ordering, which reads play_events and never touches these tables.
 * Tracks are stored denormalized (title/uri/etc. copied in at add-time)
 * rather than joined against MediaStore at read-time, because there's no
 * single indexed "all media" table across Pulse+Flux to join against —
 * this also means a playlist keeps working if a file is later renamed,
 * and simply fails to play (not silently vanishes) if it's deleted.
 */
@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    @ColumnInfo(name = "created_at_epoch_ms") val createdAtEpochMs: Long,
)

@Entity(tableName = "playlist_tracks")
data class PlaylistTrackEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @ColumnInfo(name = "playlist_id") val playlistId: Long,
    @ColumnInfo(name = "media_id") val mediaId: String,
    val uri: String,
    val title: String,
    @ColumnInfo(name = "artist_or_channel") val artistOrChannel: String?,
    @ColumnInfo(name = "duration_ms") val durationMs: Long,
    @ColumnInfo(name = "media_type") val mediaType: String, // PlayableItem.type.name
    @ColumnInfo(name = "artwork_uri") val artworkUri: String?,
    val position: Int,
    @ColumnInfo(name = "added_at_epoch_ms") val addedAtEpochMs: Long,
)

data class PlaylistWithTracks(
    val playlist: PlaylistEntity,
    val trackCount: Int,
)

@Dao
interface PlaylistDao {
    @Insert
    suspend fun insertPlaylist(playlist: PlaylistEntity): Long

    @Query("UPDATE playlists SET name = :newName WHERE id = :playlistId")
    suspend fun renamePlaylist(playlistId: Long, newName: String)

    @Query("DELETE FROM playlists WHERE id = :playlistId")
    suspend fun deletePlaylist(playlistId: Long)

    @Query("DELETE FROM playlist_tracks WHERE playlist_id = :playlistId")
    suspend fun clearTracks(playlistId: Long)

    @Transaction
    suspend fun deletePlaylistWithTracks(playlistId: Long) {
        clearTracks(playlistId)
        deletePlaylist(playlistId)
    }

    @Query(
        """
        SELECT playlists.*, (
            SELECT COUNT(*) FROM playlist_tracks WHERE playlist_tracks.playlist_id = playlists.id
        ) AS trackCount
        FROM playlists
        ORDER BY created_at_epoch_ms DESC
        """
    )
    fun playlistsWithCounts(): Flow<List<PlaylistWithTracksRow>>

    @Insert
    suspend fun insertTrack(track: PlaylistTrackEntity)

    @Query("SELECT COALESCE(MAX(position), -1) + 1 FROM playlist_tracks WHERE playlist_id = :playlistId")
    suspend fun nextPosition(playlistId: Long): Int

    @Query("DELETE FROM playlist_tracks WHERE playlist_id = :playlistId AND media_id = :mediaId")
    suspend fun removeTrack(playlistId: Long, mediaId: String)

    @Query("SELECT * FROM playlist_tracks WHERE playlist_id = :playlistId ORDER BY position ASC")
    fun tracksFor(playlistId: Long): Flow<List<PlaylistTrackEntity>>

    @Query("SELECT * FROM playlists ORDER BY created_at_epoch_ms DESC")
    fun allPlaylists(): Flow<List<PlaylistEntity>>
}

/** Room needs a concrete row shape for the joined count query above. */
data class PlaylistWithTracksRow(
    val id: Long,
    val name: String,
    @ColumnInfo(name = "created_at_epoch_ms") val createdAtEpochMs: Long,
    val trackCount: Int,
)
