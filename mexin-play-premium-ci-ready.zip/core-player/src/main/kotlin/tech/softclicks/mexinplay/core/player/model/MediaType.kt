package tech.softclicks.mexinplay.core.player.model

/**
 * Every playable item belongs to exactly one category. This is the seam
 * between the shared player core and the two themed feature modules
 * (feature-pulse for audio, feature-flux for video) — they read this
 * field to decide which theme/layout to render, not which engine plays it.
 */
enum class MediaType {
    PULSE, // audio
    FLUX,  // video
}

/**
 * Engine-agnostic description of a playable item. This is what the UI
 * layers deal with — never expose ExoPlayer's MediaItem directly outside
 * this module, so the engine can be swapped later without touching
 * feature-pulse/feature-flux.
 */
data class PlayableItem(
    val id: String,
    val uri: String,
    val title: String,
    val artistOrChannel: String?,
    val durationMs: Long,
    val type: MediaType,
    val artworkUri: String? = null,
)
