package tech.softclicks.mexinplay.core.player.history

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [PlayEventEntity::class], version = 1, exportSchema = true)
abstract class PlayHistoryDatabase : RoomDatabase() {
    abstract fun playHistoryDao(): PlayHistoryDao

    companion object {
        @Volatile
        private var instance: PlayHistoryDatabase? = null

        fun getInstance(context: Context): PlayHistoryDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    PlayHistoryDatabase::class.java,
                    "mexinplay_history.db",
                ).build().also { instance = it }
            }
    }
}
