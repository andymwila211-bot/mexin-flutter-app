package tech.softclicks.mexinplay.core.player.playlist

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import tech.softclicks.mexinplay.core.player.model.MediaType
import tech.softclicks.mexinplay.core.player.model.PlayableItem

data class PlaylistSummary(val id: Long, val name: String, val trackCount: Int)

class PlaylistRepository(private val dao: PlaylistDao) {

    fun playlists(): Flow<List<PlaylistSummary>> =
        dao.playlistsWithCounts().map { rows -> rows.map { PlaylistSummary(it.id, it.name, it.trackCount) } }

    fun tracksFor(playlistId: Long): Flow<List<PlayableItem>> =
        dao.tracksFor(playlistId).map { rows -> rows.map { it.toPlayableItem() } }

    suspend fun createPlaylist(name: String): Long =
        dao.insertPlaylist(PlaylistEntity(name = name, createdAtEpochMs = System.currentTimeMillis()))

    suspend fun renamePlaylist(playlistId: Long, newName: String) = dao.renamePlaylist(playlistId, newName)

    suspend fun deletePlaylist(playlistId: Long) = dao.deletePlaylistWithTracks(playlistId)

    suspend fun addTrack(playlistId: Long, item: PlayableItem) {
        val position = dao.nextPosition(playlistId)
        dao.insertTrack(
            PlaylistTrackEntity(
                playlistId = playlistId,
                mediaId = item.id,
                uri = item.uri,
                title = item.title,
                artistOrChannel = item.artistOrChannel,
                durationMs = item.durationMs,
                mediaType = item.type.name,
                artworkUri = item.artworkUri,
                position = position,
                addedAtEpochMs = System.currentTimeMillis(),
            )
        )
    }

    suspend fun removeTrack(playlistId: Long, mediaId: String) = dao.removeTrack(playlistId, mediaId)

    private fun PlaylistTrackEntity.toPlayableItem() = PlayableItem(
        id = mediaId,
        uri = uri,
        title = title,
        artistOrChannel = artistOrChannel,
        durationMs = durationMs,
        type = runCatching { MediaType.valueOf(mediaType) }.getOrDefault(MediaType.PULSE),
        artworkUri = artworkUri,
    )
}
