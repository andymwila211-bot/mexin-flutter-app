package tech.softclicks.mexinplay.core.player.playlist

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

/**
 * Separate Room database from PlayHistoryDatabase on purpose: playlists
 * are user data the person would be upset to lose, history is a
 * disposable ranking signal. Keeping them apart means a future "clear my
 * listening history" feature can wipe one file without touching the
 * other, and a schema mistake in one never risks a migration on both.
 */
@Database(entities = [PlaylistEntity::class, PlaylistTrackEntity::class], version = 1, exportSchema = true)
abstract class PlaylistDatabase : RoomDatabase() {
    abstract fun playlistDao(): PlaylistDao

    companion object {
        @Volatile
        private var instance: PlaylistDatabase? = null

        fun getInstance(context: Context): PlaylistDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    PlaylistDatabase::class.java,
                    "mexinplay_playlists.db",
                ).build().also { instance = it }
            }
    }
}
