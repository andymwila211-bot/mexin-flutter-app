package tech.softclicks.mexinplay.app

import android.app.Application
import tech.softclicks.mexinplay.core.player.PlaybackController
import tech.softclicks.mexinplay.core.player.history.PlayHistoryDatabase
import tech.softclicks.mexinplay.core.player.playlist.PlaylistDatabase
import tech.softclicks.mexinplay.core.player.playlist.PlaylistRepository

/**
 * Owns the one PlaybackController, PlayHistoryDatabase, and
 * PlaylistDatabase instance for the whole app. Pulse and Flux screens
 * both read from this — see PlaybackController's own doc comment for
 * why there's only one engine instance instead of one per section.
 */
class MexinPlayApplication : Application() {

    lateinit var playbackController: PlaybackController
        private set

    lateinit var playlistRepository: PlaylistRepository
        private set

    override fun onCreate() {
        super.onCreate()
        val historyDao = PlayHistoryDatabase.getInstance(this).playHistoryDao()
        playbackController = PlaybackController(
            context = this,
            historyDao = historyDao,
        )
        playlistRepository = PlaylistRepository(PlaylistDatabase.getInstance(this).playlistDao())
    }
}
