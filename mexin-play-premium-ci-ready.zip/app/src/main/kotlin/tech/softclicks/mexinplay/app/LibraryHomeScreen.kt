package tech.softclicks.mexinplay.app

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import tech.softclicks.mexinplay.core.player.model.MediaType
import tech.softclicks.mexinplay.core.player.model.PlayableItem
import tech.softclicks.mexinplay.core.ui.glass.ShellColors

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LibraryHomeScreen(
    pulseItems: List<PlayableItem>,
    fluxItems: List<PlayableItem>,
    nowPlaying: PlayableItem?,
    isPlaying: Boolean,
    onPlay: (PlayableItem, List<PlayableItem>) -> Unit,
    onOpenPlayer: () -> Unit,
    onSearch: () -> Unit,
    onPlaylists: () -> Unit,
    onLongPress: (PlayableItem) -> Unit,
    modifier: Modifier = Modifier,
) {
    var selectedType by remember { mutableIntStateOf(0) }
    val items = if (selectedType == 0) pulseItems else fluxItems
    val title = if (selectedType == 0) "Music" else "Cinema"
    val subtitle = if (selectedType == 0) "Your audio library" else "Your video library"

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ShellColors.base),
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .padding(bottom = 104.dp),
        ) {
        HomeHeader(onSearch = onSearch, onPlaylists = onPlaylists)

        Column(modifier = Modifier.padding(horizontal = 20.dp)) {
            Text(
                text = "YOUR LIBRARY",
                color = Color.White.copy(alpha = .42f),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.8.sp,
            )
            Text(
                text = "Made for you.",
                color = Color.White,
                fontSize = 36.sp,
                lineHeight = 39.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = (-1.2).sp,
                modifier = Modifier.padding(top = 4.dp),
            )
            Text(
                text = "Everything on this device, beautifully organized.",
                color = Color.White.copy(alpha = .46f),
                fontSize = 14.sp,
                modifier = Modifier.padding(top = 7.dp, bottom = 22.dp),
            )

            LibraryDeck(
                selectedType = selectedType,
                onSelect = { selectedType = it },
                itemCount = items.size,
            )

            Spacer(modifier = Modifier.height(26.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Bottom,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(title, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
                    Text(subtitle, color = Color.White.copy(alpha = .4f), fontSize = 13.sp)
                }
                Text("${items.size} files", color = Color.White.copy(alpha = .4f), fontSize = 13.sp)
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (items.isEmpty()) {
                EmptyLibraryCard(type = selectedType)
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.fillMaxWidth().height((items.size.coerceAtMost(8) / 2 + if (items.size.coerceAtMost(8) % 2 == 0) 0 else 1) * 220.dp),
                    contentPadding = PaddingValues(bottom = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp),
                    userScrollEnabled = false,
                ) {
                    items(items.take(8), key = { it.id }) { item ->
                        LibraryFileCard(
                            item = item,
                            onClick = { onPlay(item, items) },
                            onLongPress = { onLongPress(item) },
                        )
                    }
                }
            }
        }

        nowPlaying?.let {
        MiniPlayer(
            item = it,
            isPlaying = isPlaying,
            onOpen = onOpenPlayer,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(horizontal = 14.dp, vertical = 12.dp),
        )
        }
    }
}

@Composable
private fun HomeHeader(onSearch: () -> Unit, onPlaylists: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text("MEXIN", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
            Text("PLAY", color = Color.White.copy(alpha = .38f), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.8.sp)
        }
        HomeIconButton(Icons.Filled.Search, "Search", onSearch)
        Spacer(Modifier.width(8.dp))
        HomeIconButton(Icons.Filled.AutoAwesome, "Playlists", onPlaylists)
    }
}

@Composable
private fun HomeIconButton(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = .055f))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = label, tint = Color.White.copy(alpha = .78f), modifier = Modifier.size(19.dp))
    }
}

@Composable
private fun LibraryDeck(selectedType: Int, onSelect: (Int) -> Unit, itemCount: Int) {
    val musicRotation by animateFloatAsState(if (selectedType == 0) 0f else -5.5f, spring(stiffness = Spring.StiffnessLow), label = "musicRotation")
    val cinemaRotation by animateFloatAsState(if (selectedType == 1) 0f else 5.5f, spring(stiffness = Spring.StiffnessLow), label = "cinemaRotation")
    val musicX by animateDpAsState(if (selectedType == 0) 0.dp else (-24).dp, spring(stiffness = Spring.StiffnessMediumLow), label = "musicX")
    val cinemaX by animateDpAsState(if (selectedType == 1) 0.dp else 24.dp, spring(stiffness = Spring.StiffnessMediumLow), label = "cinemaX")
    val musicScale by animateFloatAsState(if (selectedType == 0) 1f else .94f, spring(stiffness = Spring.StiffnessMediumLow), label = "musicScale")
    val cinemaScale by animateFloatAsState(if (selectedType == 1) 1f else .94f, spring(stiffness = Spring.StiffnessMediumLow), label = "cinemaScale")

    Box(modifier = Modifier.fillMaxWidth().height(205.dp)) {
        DeckCard(
            title = "Music",
            subtitle = "$itemCount tracks",
            icon = Icons.Filled.GraphicEq,
            accent = Color(0xFFB9B9C4),
            rotation = musicRotation,
            translationX = musicX,
            scale = musicScale,
            selected = selectedType == 0,
            onClick = { onSelect(0) },
        )
        DeckCard(
            title = "Cinema",
            subtitle = "Your videos",
            icon = Icons.Filled.Movie,
            accent = Color(0xFFDADAE2),
            rotation = cinemaRotation,
            translationX = cinemaX,
            scale = cinemaScale,
            selected = selectedType == 1,
            onClick = { onSelect(1) },
        )
    }
}

@Composable
private fun DeckCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accent: Color,
    rotation: Float,
    translationX: androidx.compose.ui.unit.Dp,
    scale: Float,
    selected: Boolean,
    onClick: () -> Unit,
) {
    val lift by animateDpAsState(if (selected) 0.dp else 10.dp, spring(stiffness = Spring.StiffnessLow), label = "lift")
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(190.dp)
            .padding(horizontal = 2.dp)
            .graphicsLayer {
                rotationY = rotation
                translationX = translationX.toPx()
                translationY = lift.toPx()
                scaleX = scale
                scaleY = scale
                cameraDistance = 26f * density
            }
            .clip(RoundedCornerShape(30.dp))
            .background(Color(0xFF151519))
            .clickable(onClick = onClick)
            .padding(24.dp),
    ) {
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .size(74.dp)
                .graphicsLayer { rotationZ = if (selected) 0f else 8f }
                .clip(CircleShape)
                .background(Color.White.copy(alpha = .065f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = accent.copy(alpha = .9f), modifier = Modifier.size(31.dp))
        }
        Column(modifier = Modifier.align(Alignment.BottomStart)) {
            Text(
                text = title,
                color = Color.White,
                fontSize = 30.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = (-.7).sp,
            )
            Text(subtitle, color = Color.White.copy(alpha = .43f), fontSize = 13.sp, modifier = Modifier.padding(top = 3.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(top = 16.dp),
            ) {
                Box(Modifier.size(7.dp).clip(CircleShape).background(Color.White.copy(alpha = .72f)))
                Spacer(Modifier.width(7.dp))
                Text(if (selected) "OPEN LIBRARY" else "SWITCH", color = Color.White.copy(alpha = .42f), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun LibraryFileCard(item: PlayableItem, onClick: () -> Unit, onLongPress: () -> Unit) {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (pressed) .965f else 1f, spring(stiffness = Spring.StiffnessMedium), label = "press")
    Column(
        modifier = Modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongPress,
                onClickLabel = "Play ${item.title}",
            ),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(.92f)
                .clip(RoundedCornerShape(22.dp))
                .background(Color(0xFF17171C)),
        ) {
            if (item.artworkUri != null) {
                AsyncImage(item.artworkUri, contentDescription = "${item.title} artwork", modifier = Modifier.fillMaxSize())
            } else {
                val icon = if (item.type == MediaType.PULSE) Icons.Filled.GraphicEq else Icons.Filled.VideoLibrary
                Icon(icon, contentDescription = null, tint = Color.White.copy(alpha = .18f), modifier = Modifier.align(Alignment.Center).size(42.dp))
            }
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(10.dp)
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(Color.White),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
            }
        }
        Text(item.title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 9.dp))
        item.artistOrChannel?.let {
            Text(it, color = Color.White.copy(alpha = .38f), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
        }
    }
}

@Composable
private fun EmptyLibraryCard(type: Int) {
    Box(
        modifier = Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(24.dp)).background(Color.White.copy(alpha = .035f)),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(if (type == 0) Icons.Filled.GraphicEq else Icons.Filled.VideoLibrary, null, tint = Color.White.copy(alpha = .28f), modifier = Modifier.size(32.dp))
            Text("No files here yet", color = Color.White.copy(alpha = .62f), fontSize = 15.sp, modifier = Modifier.padding(top = 10.dp))
            Text("Add media to this device and come back.", color = Color.White.copy(alpha = .34f), fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        }
    }
}

@Composable
private fun MiniPlayer(item: PlayableItem, isPlaying: Boolean, onOpen: () -> Unit, modifier: Modifier = Modifier) {
    val accent by animateColorAsState(Color.White, label = "miniAccent")
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(66.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(Color(0xFF19191E))
            .clickable(onClick = onOpen)
            .padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = .06f))) {
            if (item.artworkUri != null) AsyncImage(item.artworkUri, contentDescription = null, modifier = Modifier.fillMaxSize())
            else Icon(if (item.type == MediaType.PULSE) Icons.Filled.GraphicEq else Icons.Filled.Movie, null, tint = Color.White.copy(alpha = .35f), modifier = Modifier.align(Alignment.Center).size(20.dp))
        }
        Column(Modifier.weight(1f).padding(horizontal = 11.dp)) {
            Text(item.title, color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(if (isPlaying) "Playing now" else "Paused", color = Color.White.copy(alpha = .4f), fontSize = 11.sp)
        }
        Icon(Icons.Filled.PlayArrow, contentDescription = "Open player", tint = accent, modifier = Modifier.size(22.dp))
    }
}
