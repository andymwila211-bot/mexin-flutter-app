package tech.softclicks.mexinplay.app

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloseFullscreen
import androidx.compose.material.icons.filled.OpenInFull
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import tech.softclicks.mexinplay.core.player.model.PlayableItem

/**
 * Content for Discover's ModalBottomSheet (see MexinNavHost) — a real
 * sub-screen reached via a button, not an inline list on the player
 * screen. Starts at partial height; [isExpanded] plus [onToggleExpand]
 * give an explicit control to go full-screen rather than relying on
 * drag alone, since drag-to-expand isn't discoverable on its own.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DiscoverSheetContent(
    items: List<PlayableItem>,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit,
    onSelectItem: (PlayableItem) -> Unit,
    onLongPressItem: (PlayableItem) -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(modifier = modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(text = "Discover", fontSize = 18.sp, color = Color.White)
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.08f))
                    .clickable(onClick = onToggleExpand),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = if (isExpanded) Icons.Filled.CloseFullscreen else Icons.Filled.OpenInFull,
                    contentDescription = if (isExpanded) "Collapse" else "Expand to full screen",
                    tint = Color.White.copy(alpha = 0.8f),
                    modifier = Modifier.size(16.dp),
                )
            }
        }

        if (items.isEmpty()) {
            Text(text = "Nothing here yet.", color = Color.White.copy(alpha = 0.5f), fontSize = 14.sp)
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(if (isExpanded) 3 else 2),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                items(items, key = { it.id }) { item ->
                    DiscoverGridCard(
                        item = item,
                        onClick = { onSelectItem(item) },
                        onLongClick = { onLongPressItem(item) },
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun DiscoverGridCard(item: PlayableItem, onClick: () -> Unit, onLongClick: () -> Unit) {
    Column(modifier = Modifier.combinedClickable(onClick = onClick, onLongClick = onLongClick)) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0xFF17171C)),
        ) {
            if (item.artworkUri != null) {
                AsyncImage(
                    model = item.artworkUri,
                    contentDescription = "${item.title} artwork",
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = item.title, color = Color.White, fontSize = 14.sp, maxLines = 1)
        item.artistOrChannel?.let {
            Text(text = it, color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp, maxLines = 1)
        }
    }
}
