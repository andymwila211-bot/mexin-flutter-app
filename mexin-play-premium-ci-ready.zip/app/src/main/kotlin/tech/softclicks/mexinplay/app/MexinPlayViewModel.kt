package tech.softclicks.mexinplay.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import tech.softclicks.mexinplay.core.player.history.PlayHistoryDatabase
import tech.softclicks.mexinplay.core.player.library.MediaLibraryRepository
import tech.softclicks.mexinplay.core.player.model.PlayableItem
import tech.softclicks.mexinplay.core.player.playlist.PlaylistSummary
import tech.softclicks.mexinplay.core.player.shuffle.SmartShuffleEngine

/**
 * First real connection between the pieces built in earlier phases:
 * MediaLibraryRepository (device files) -> SmartShuffleEngine (orders
 * them using real play history) -> PlaybackController (actually plays
 * them). Screens read from this instead of being handed null/hardcoded
 * lists. Playlists are a separate, user-driven data source — see
 * PlaylistRepository — that never runs through the shuffle engine.
 */
class MexinPlayViewModel(application: Application) : AndroidViewModel(application) {

    private val app get() = getApplication<Application>() as MexinPlayApplication
    private val repository = MediaLibraryRepository(application)
    private val shuffleEngine = SmartShuffleEngine()
    private val playlistRepository get() = app.playlistRepository

    private val _pulseQueue = MutableStateFlow<List<PlayableItem>>(emptyList())
    val pulseQueue: StateFlow<List<PlayableItem>> = _pulseQueue.asStateFlow()

    private val _fluxQueue = MutableStateFlow<List<PlayableItem>>(emptyList())
    val fluxQueue: StateFlow<List<PlayableItem>> = _fluxQueue.asStateFlow()

    private val _nowPlaying = MutableStateFlow<PlayableItem?>(null)
    val nowPlaying: StateFlow<PlayableItem?> = _nowPlaying.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    val playlists: StateFlow<List<PlaylistSummary>> by lazy {
        playlistRepository.playlists().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    }

    private var activeQueue: List<PlayableItem> = emptyList()
    private var currentIndex: Int = -1

    /** Call once permission is confirmed granted — this class doesn't check permissions itself. */
    fun loadLibraries() {
        viewModelScope.launch {
            val pulseItems = repository.loadPulseLibrary()
            val fluxItems = repository.loadFluxLibrary()

            val historyDao = PlayHistoryDatabase.getInstance(getApplication()).playHistoryDao()
            val statsByMediaId = historyDao.aggregatedStats().first().associateBy { it.mediaId }
            val now = System.currentTimeMillis()
            val hour = SmartShuffleEngine.currentHourOfDay()

            _pulseQueue.value = shuffleEngine.weightedShuffle(pulseItems, statsByMediaId, now, hour)
            _fluxQueue.value = shuffleEngine.weightedShuffle(fluxItems, statsByMediaId, now, hour)
        }
    }

    fun play(item: PlayableItem, queue: List<PlayableItem>) {
        activeQueue = queue
        currentIndex = queue.indexOfFirst { it.id == item.id }
        app.playbackController.play(item)
        _nowPlaying.value = item
        _isPlaying.value = true
    }

    fun togglePlayPause() {
        if (_nowPlaying.value == null) return
        if (_isPlaying.value) {
            app.playbackController.pause()
            _isPlaying.value = false
        } else {
            app.playbackController.resume()
            _isPlaying.value = true
        }
    }

    fun playNext() = moveBy(1)

    fun playPrevious() = moveBy(-1)

    private fun moveBy(delta: Int) {
        if (activeQueue.isEmpty() || currentIndex < 0) return
        val newIndex = (currentIndex + delta + activeQueue.size) % activeQueue.size
        play(activeQueue[newIndex], activeQueue)
    }

    fun tracksForPlaylist(playlistId: Long) = playlistRepository.tracksFor(playlistId)

    fun createPlaylist(name: String) {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) return
        viewModelScope.launch { playlistRepository.createPlaylist(trimmed) }
    }

    fun renamePlaylist(playlistId: Long, newName: String) {
        val trimmed = newName.trim()
        if (trimmed.isEmpty()) return
        viewModelScope.launch { playlistRepository.renamePlaylist(playlistId, trimmed) }
    }

    fun deletePlaylist(playlistId: Long) {
        viewModelScope.launch { playlistRepository.deletePlaylist(playlistId) }
    }

    fun addToPlaylist(playlistId: Long, item: PlayableItem) {
        viewModelScope.launch { playlistRepository.addTrack(playlistId, item) }
    }

    /** Long-press "add to playlist" when the user types a brand-new name instead of picking one. */
    fun createPlaylistAndAdd(name: String, item: PlayableItem) {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) return
        viewModelScope.launch {
            val id = playlistRepository.createPlaylist(trimmed)
            playlistRepository.addTrack(id, item)
        }
    }

    fun removeFromPlaylist(playlistId: Long, mediaId: String) {
        viewModelScope.launch { playlistRepository.removeTrack(playlistId, mediaId) }
    }
}
