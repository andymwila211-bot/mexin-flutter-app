package tech.softclicks.mexinplay.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import tech.softclicks.mexinplay.core.player.PlaybackController
import tech.softclicks.mexinplay.core.player.model.MediaType
import tech.softclicks.mexinplay.core.player.model.PlayableItem
import tech.softclicks.mexinplay.core.ui.glass.ShellColors
import tech.softclicks.mexinplay.feature.flux.FluxHomeScreen
import tech.softclicks.mexinplay.feature.pulse.PulseHomeScreen

private const val ROUTE_HOME = "home"
private const val ROUTE_PULSE = "pulse"
private const val ROUTE_FLUX = "flux"

private sealed class PlaylistOverlay {
    data object Hidden : PlaylistOverlay()
    data object List : PlaylistOverlay()
    data class Detail(val playlistId: Long, val playlistName: String) : PlaylistOverlay()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MexinNavHost(playbackController: PlaybackController, viewModel: MexinPlayViewModel) {
    val navController = rememberNavController()
    val backStack by navController.currentBackStackEntryAsState()
    val route = backStack?.destination?.route ?: ROUTE_HOME

    val pulseQueue by viewModel.pulseQueue.collectAsState()
    val fluxQueue by viewModel.fluxQueue.collectAsState()
    val nowPlaying by viewModel.nowPlaying.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    val playlists by viewModel.playlists.collectAsState()

    var searchOpen by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var playlistOverlay by remember { mutableStateOf<PlaylistOverlay>(PlaylistOverlay.Hidden) }
    var addItem by remember { mutableStateOf<PlayableItem?>(null) }

    val filteredPulse = remember(pulseQueue, query) {
        if (query.isBlank()) pulseQueue else pulseQueue.filter { it.title.contains(query, true) || it.artistOrChannel.orEmpty().contains(query, true) }
    }
    val filteredFlux = remember(fluxQueue, query) {
        if (query.isBlank()) fluxQueue else fluxQueue.filter { it.title.contains(query, true) || it.artistOrChannel.orEmpty().contains(query, true) }
    }

    Box(Modifier.fillMaxSize().background(ShellColors.base)) {
        androidx.navigation.compose.NavHost(
            navController = navController,
            startDestination = ROUTE_HOME,
            modifier = Modifier.fillMaxSize(),
        ) {
            composable(ROUTE_HOME) {
                LibraryHomeScreen(
                    pulseItems = filteredPulse,
                    fluxItems = filteredFlux,
                    nowPlaying = nowPlaying,
                    isPlaying = isPlaying,
                    onPlay = { item, queue ->
                        viewModel.play(item, queue)
                        navController.navigate(if (item.type == MediaType.PULSE) ROUTE_PULSE else ROUTE_FLUX)
                    },
                    onOpenPlayer = {
                        nowPlaying?.let { navController.navigate(if (it.type == MediaType.PULSE) ROUTE_PULSE else ROUTE_FLUX) }
                    },
                    onSearch = { searchOpen = true },
                    onPlaylists = { playlistOverlay = PlaylistOverlay.List },
                    onLongPress = { addItem = it },
                )
            }
            composable(ROUTE_PULSE) {
                PulseHomeScreen(
                    nowPlaying = nowPlaying,
                    isPlaying = isPlaying,
                    onPlayPause = viewModel::togglePlayPause,
                    onNext = viewModel::playNext,
                    onPrevious = viewModel::playPrevious,
                    onOpenLibrary = { navController.popBackStack() },
                    playbackController = playbackController,
                )
            }
            composable(ROUTE_FLUX) {
                FluxHomeScreen(
                    nowPlaying = nowPlaying,
                    isPlaying = isPlaying,
                    onPlayPause = viewModel::togglePlayPause,
                    onNext = viewModel::playNext,
                    onPrevious = viewModel::playPrevious,
                    onOpenLibrary = { navController.popBackStack() },
                    playbackController = playbackController,
                )
            }
        }

        if (route != ROUTE_HOME) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(16.dp)
                    .size(44.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(Color.Black.copy(alpha = .34f))
                    .border(1.dp, Color.White.copy(alpha = .09f), RoundedCornerShape(22.dp))
                    .clickable { navController.popBackStack() },
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Filled.Close, "Back to library", tint = Color.White, modifier = Modifier.size(18.dp))
            }
        }

        if (searchOpen && route == ROUTE_HOME) {
            SearchOverlay(
                query = query,
                onQueryChange = { query = it },
                onClose = { searchOpen = false; query = "" },
                modifier = Modifier.align(Alignment.TopCenter).padding(horizontal = 20.dp, vertical = 16.dp),
            )
        }

        when (val overlay = playlistOverlay) {
            PlaylistOverlay.Hidden -> Unit
            PlaylistOverlay.List -> {
                Box(Modifier.fillMaxSize().background(ShellColors.base)) {
                    PlaylistsScreen(
                        playlists = playlists,
                        onCreatePlaylist = viewModel::createPlaylist,
                        onDeletePlaylist = viewModel::deletePlaylist,
                        onOpenPlaylist = { id ->
                            val name = playlists.firstOrNull { it.id == id }?.name.orEmpty()
                            playlistOverlay = PlaylistOverlay.Detail(id, name)
                        },
                        onBack = { playlistOverlay = PlaylistOverlay.Hidden },
                    )
                }
            }
            is PlaylistOverlay.Detail -> {
                val tracks by remember(overlay.playlistId) {
                    viewModel.tracksForPlaylist(overlay.playlistId)
                }.collectAsState(initial = emptyList())
                Box(Modifier.fillMaxSize().background(ShellColors.base)) {
                    PlaylistDetailScreen(
                        playlistName = overlay.playlistName,
                        tracks = tracks,
                        onPlay = { viewModel.play(it, tracks); navController.navigate(if (it.type == MediaType.PULSE) ROUTE_PULSE else ROUTE_FLUX) },
                        onRemove = { mediaId -> viewModel.removeFromPlaylist(overlay.playlistId, mediaId) },
                        onBack = { playlistOverlay = PlaylistOverlay.List },
                    )
                }
            }
        }

        addItem?.let { item ->
            val sheet = rememberModalBottomSheetState(skipPartiallyExpanded = true)
            ModalBottomSheet(
                onDismissRequest = { addItem = null },
                sheetState = sheet,
                containerColor = Color(0xFF151519),
            ) {
                AddToPlaylistSheetContent(
                    item = item,
                    playlists = playlists,
                    onPickPlaylist = { id -> viewModel.addToPlaylist(id, item); addItem = null },
                    onCreateAndAdd = { name -> viewModel.createPlaylistAndAdd(name, item); addItem = null },
                )
            }
        }
    }
}

@Composable
private fun SearchOverlay(
    query: String,
    onQueryChange: (String) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(Color(0xFF17171C))
            .border(1.dp, Color.White.copy(alpha = .08f), RoundedCornerShape(24.dp))
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Search, null, tint = Color.White.copy(alpha = .55f), modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(10.dp))
        BasicTextField(
            value = query,
            onValueChange = onQueryChange,
            singleLine = true,
            textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
            cursorBrush = androidx.compose.ui.graphics.SolidColor(Color.White),
            modifier = Modifier.weight(1f),
        )
        Icon(Icons.Filled.Close, "Close", tint = Color.White.copy(alpha = .65f), modifier = Modifier.size(18.dp).clickable(onClick = onClose))
    }
}
