package tech.softclicks.mexinplay.core.ui.glass

import android.content.Context
import android.graphics.Bitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.palette.graphics.Palette
import coil.ImageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class ArtworkColors(val vibrant: Color, val muted: Color, val darkVibrant: Color)

private val FALLBACK = ArtworkColors(
    vibrant = Color(0xFF2A2A32),
    muted = Color(0xFF1A1A1F),
    darkVibrant = Color(0xFF0C0C10),
)

/**
 * Decodes artwork and extracts real swatches via Palette — used two ways:
 * as LiquidBackdrop's pre-API-33 gradient fallback, and as the Bitmap
 * source LiquidBackdrop's AGSL shader animates on API 33+. Returns the
 * decoded Bitmap alongside the colors so callers don't decode twice.
 */
suspend fun loadArtworkWithPalette(context: Context, artworkUri: String?): Pair<Bitmap?, ArtworkColors> {
    if (artworkUri == null) return null to FALLBACK
    return withContext(Dispatchers.IO) {
        runCatching {
            val loader = ImageLoader(context)
            val request = ImageRequest.Builder(context)
                .data(artworkUri)
                .allowHardware(false) // Palette and the AGSL shader both need CPU-readable pixels
                .build()
            val result = loader.execute(request)
            val bitmap = (result as? SuccessResult)?.drawable?.let { drawable ->
                val bmp = Bitmap.createBitmap(drawable.intrinsicWidth.coerceAtLeast(1), drawable.intrinsicHeight.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
                val canvas = android.graphics.Canvas(bmp)
                drawable.setBounds(0, 0, canvas.width, canvas.height)
                drawable.draw(canvas)
                bmp
            } ?: return@runCatching null to FALLBACK

            val palette = Palette.from(bitmap).generate()
            val colors = ArtworkColors(
                vibrant = palette.getVibrantColor(FALLBACK.vibrant.toArgb()).let { Color(it) },
                muted = palette.getMutedColor(FALLBACK.muted.toArgb()).let { Color(it) },
                darkVibrant = palette.getDarkVibrantColor(FALLBACK.darkVibrant.toArgb()).let { Color(it) },
            )
            bitmap to colors
        }.getOrElse { null to FALLBACK }
    }
}
