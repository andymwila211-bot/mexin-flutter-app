package tech.softclicks.mexinplay.core.ui.glass

import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * Three roles, used consistently everywhere: display (headlines, heavy
 * weight + tight tracking, does the "personality" work), body (default
 * reading text), and data (monospace, reserved ONLY for numbers/durations
 * — a HUD-readout feel that's earned by the subject, not decoration
 * dropped in for texture). Uses system font families deliberately —
 * downloadable custom fonts need cert-hash XML that can't be verified
 * without a live install, not worth risking a working build for.
 */
object AppTypography {
    val eyebrow = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        letterSpacing = 2.sp,
    )

    val displayLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Black,
        fontSize = 36.sp,
        letterSpacing = (-0.8).sp,
    )

    val headline = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 18.sp,
        letterSpacing = (-0.2).sp,
    )

    val body = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
    )

    val bodyMuted = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
    )

    /** Reserved for durations, counts, timestamps — never body copy. */
    val dataMono = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Medium,
        fontSize = 13.sp,
        letterSpacing = 0.5.sp,
    )
}
