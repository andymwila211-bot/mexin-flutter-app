package tech.softclicks.mexinplay.core.ui.glass

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color

/**
 * Flat shell backdrop only — deliberately no radial glow/blob. The
 * reference screens are plain near-black with a very faint top-right
 * ambient lift (barely visible, not a colored cloud). Kept as a
 * composable rather than inlined so call sites don't change if the
 * backdrop ever needs a subtle treatment again.
 */
@Composable
fun AuraBackground(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ShellColors.base),
    )
}
