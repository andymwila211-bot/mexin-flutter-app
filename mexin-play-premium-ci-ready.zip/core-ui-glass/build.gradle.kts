plugins {
    id("com.android.library")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "tech.softclicks.mexinplay.core.ui.glass"
    compileSdk = 34

    defaultConfig {
        minSdk = 24
    }

    buildFeatures {
        compose = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.10.01")
    implementation(composeBom)

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui-tooling-preview")
    debugImplementation("androidx.compose.ui:ui-tooling")

    // Palette extracts dominant/vibrant/muted swatches from decoded artwork —
    // powers the pre-API-33 gradient fallback in LiquidBackdrop.kt, and could
    // later drive accent-color theming elsewhere.
    implementation("androidx.palette:palette-ktx:1.0.0")

    // Loads the artwork bitmap LiquidBackdrop.kt animates — separate from the
    // AsyncImage/coil-compose used for static thumbnails in feature-pulse/flux,
    // since this module needs the raw Bitmap for shader/Palette input, not a
    // composable-rendered image.
    implementation("io.coil-kt:coil:2.7.0")

    // NOTE: Kyant0/AndroidLiquidGlass (Apache 2.0) for panel-level frosted
    // glass is still a separate follow-up — LiquidBackdrop.kt below covers
    // the animated artwork background specifically, not glass chrome on
    // cards/buttons. Haze is no longer the plan for that; see LiquidBackdrop's
    // doc comment for why a real AGSL twist shader was built instead.
}
